import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
os.environ['CUDA_VISIBLE_DEVICES'] = ''

from tensorflow.lite.python.interpreter import Interpreter

import argparse
import operator
import soundfile as sf
import numpy as np
import math
import time
import csv
import resampy

def loadModel():
    global INPUT_LAYER_INDEX
    global OUTPUT_LAYER_INDEX
    global MDATA_INPUT_INDEX
    global CLASSES

    print('LOADING TF LITE MODEL...', end=' ')
    interpreter = Interpreter(model_path='model/BirdNET_6K_GLOBAL_MODEL.tflite')
    interpreter.allocate_tensors()

    input_details = interpreter.get_input_details()
    output_details = interpreter.get_output_details()
    INPUT_LAYER_INDEX = input_details[0]['index']
    MDATA_INPUT_INDEX = input_details[1]['index']
    OUTPUT_LAYER_INDEX = output_details[0]['index']

    CLASSES = []
    with open('model/labels.txt', 'r') as lfile:
        for line in lfile.readlines():
            CLASSES.append(line.strip())

    print('DONE!')
    return interpreter

def loadCustomSpeciesList(path):
    slist = []
    if os.path.isfile(path):
        with open(path, 'r') as csfile:
            for line in csfile.readlines():
                slist.append(line.strip())
    return slist

def splitSignal(sig, rate, overlap, seconds=3.0, minlen=1.5):
    sig_splits = []
    for i in range(0, len(sig), int((seconds - overlap) * rate)):
        split = sig[i:i + int(seconds * rate)]
        if len(split) < int(minlen * rate):
            break
        if len(split) < int(rate * seconds):
            temp = np.zeros((int(rate * seconds)))
            temp[:len(split)] = split
            split = temp
        sig_splits.append(split)
    return sig_splits

def readAudioData(path, overlap, sample_rate=48000):
    print('READING AUDIO DATA...', end=' ', flush=True)

    sig, rate = sf.read(path)

    if rate != sample_rate:
        sig = resampy.resample(sig, sr_orig=rate, sr_new=sample_rate)
        rate = sample_rate

    if sig.ndim > 1:
        sig = sig.mean(axis=1)

    chunks = splitSignal(sig, rate, overlap)
    print('DONE! READ', str(len(chunks)), 'CHUNKS.')
    return chunks

def convertMetadata(m):
    if 1 <= m[2] <= 48:
        m[2] = math.cos(math.radians(m[2] * 7.5)) + 1 
    else:
        m[2] = -1
    mask = np.ones((3,))
    if m[0] == -1 or m[1] == -1:
        mask = np.zeros((3,))
    if m[2] == -1:
        mask[2] = 0.0
    return np.concatenate([m, mask])

def custom_sigmoid(x, sensitivity=1.0):
    return 1 / (1.0 + np.exp(-sensitivity * x))

def predict(sample, interpreter, sensitivity):
    interpreter.set_tensor(INPUT_LAYER_INDEX, np.array(sample[0], dtype='float32'))
    interpreter.set_tensor(MDATA_INPUT_INDEX, np.array(sample[1], dtype='float32'))
    interpreter.invoke()
    prediction = interpreter.get_tensor(OUTPUT_LAYER_INDEX)[0]
    p_sigmoid = custom_sigmoid(prediction, sensitivity)
    p_labels = dict(zip(CLASSES, p_sigmoid))
    p_sorted = sorted(p_labels.items(), key=operator.itemgetter(1), reverse=True)
    for i in range(min(10, len(p_sorted))):
        if p_sorted[i][0] in ['Human_Human', 'Non-bird_Non-bird', 'Noise_Noise']:
            p_sorted[i] = (p_sorted[i][0], 0.0)
    return p_sorted[:10]

def analyzeAudioData(chunks, lat, lon, week, sensitivity, overlap, interpreter):
    detections = {}
    start = time.time()
    print('ANALYZING AUDIO...', end=' ', flush=True)
    mdata = convertMetadata(np.array([lat, lon, week]))
    mdata = np.expand_dims(mdata, 0)
    pred_start = 0.0
    for c in chunks:
        sig = np.expand_dims(c, 0)
        p = predict([sig, mdata], interpreter, sensitivity)
        pred_end = pred_start + 3.0
        detections[f"{pred_start:.2f};{pred_end:.2f}"] = p
        pred_start = pred_end - overlap
    print('DONE! Time', int((time.time() - start) * 10) / 10.0, 'SECONDS')
    return detections

def writeResultsToFile(detections, min_conf, path):
    print('WRITING RESULTS TO', path, '...', end=' ')
    rcnt = 0
    with open(path, 'w', newline='') as rfile:
        writer = csv.writer(rfile, delimiter=';')
        writer.writerow(['Start (s)', 'End (s)', 'Scientific name', 'Common name', 'Confidence'])
        for d in detections:
            start_s, end_s = d.split(';')
            for entry in detections[d]:
                if entry[1] >= min_conf and (entry[0] in WHITE_LIST or len(WHITE_LIST) == 0):
                    sci_name, com_name = entry[0].split('_', 1)
                    writer.writerow([start_s, end_s, sci_name, com_name, f"{entry[1]:.5f}"])
                    rcnt += 1
    print('DONE! WROTE', rcnt, 'RESULTS.')

def main():
    global WHITE_LIST

    parser = argparse.ArgumentParser()
    parser.add_argument('--i', help='Path to input file.')
    parser.add_argument('--o', default='result.csv', help='Path to output file. Defaults to result.csv.')
    parser.add_argument('--lat', type=float, default=-1)
    parser.add_argument('--lon', type=float, default=-1)
    parser.add_argument('--week', type=int, default=-1)
    parser.add_argument('--overlap', type=float, default=0.0)
    parser.add_argument('--sensitivity', type=float, default=1.0)
    parser.add_argument('--min_conf', type=float, default=0.1)
    parser.add_argument('--custom_list', default='')

    args = parser.parse_args()
    interpreter = loadModel()

    WHITE_LIST = loadCustomSpeciesList(args.custom_list) if args.custom_list else []
    audioData = readAudioData(args.i, args.overlap)
    week = max(1, min(args.week, 48))
    sensitivity = max(0.5, min(1.0 - (args.sensitivity - 1.0), 1.5))
    detections = analyzeAudioData(audioData, args.lat, args.lon, week, sensitivity, args.overlap, interpreter)
    min_conf = max(0.01, min(args.min_conf, 0.99))
    writeResultsToFile(detections, min_conf, args.o)

if __name__ == '__main__':
    main()
